from app import app

# production setup
app.config['DEBUG'] = False
app.config['use_reloader'] = False
app.config['threaded'] = True