import sqlite3
import datetime
import sys
from flask import Flask, request, make_response, jsonify, Response

# Instantiate Flask Class
app = Flask(__name__)
connection = sqlite3.connect("Data/GameAPI", check_same_thread=False, detect_types=sqlite3.PARSE_DECLTYPES | sqlite3.PARSE_COLNAMES)
cursor = connection.cursor()

# Validate User
def validate_user(username, password):
    user_name = username
    User_password = password

    rows = cursor.execute("SELECT ID, FNAME,SNAME,PASSWORD,API,USERNAME FROM USER WHERE USERNAME = ? AND PASSWORD = ?", (user_name, password), ).fetchall()
    if len(rows) == 1:
        return True
    else:
        return False


@app.route('/api/v1/auth/', methods=['POST'])
def get_user_details():
    data = request.json
    username = data['username']
    first_name = data['first_name']
    last_name = data['last_name']
    password = data['password']
    result = jsonify({'username': username, 'first_name': first_name, 'last_name': last_name, 'Authenticated': str(validate_user(username, password))}, )
    api_response: Response = make_response(result)
    api_response.headers["api_version"] = '1.0'
    api_response.headers["Content-Type"] = 'application/json'
    api_response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
    api_response.headers['Content-Security-Policy'] = "default-src 'self'"
    api_response.headers['X-Content-Type-Options'] = 'nosniff'
    api_response.headers['X-Frame-Options'] = 'SAMEORIGIN'
    return api_response


@app.route('/api/v1/policy/<string:token_id>', methods=['POST'])
def get_policy(token_id):
    try:
        token = token_id
        policy = cursor.execute("SELECT DISTINCT POLICY FROM POLICY WHERE API_KEY=?", (token,)).fetchone()
        if len(policy) > 0:
            api_response: Response = make_response({'API_KEY': token, 'Policy': policy[0]})
            api_response.headers["api_version"] = '1.0'
            api_response.headers["Content-Type"] = 'application/json'
            api_response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
            api_response.headers['Content-Security-Policy'] = "default-src 'self'"
            api_response.headers['X-Content-Type-Options'] = 'nosniff'
            api_response.headers['X-Frame-Options'] = 'SAMEORIGIN'
            return api_response
        else:
            return make_response({'Error': 'Invalid Api Key provided'})
    except ValueError:
        return make_response({'Error': 'Badly formatted data'})
    except KeyError:
        return make_response({'Error': 'Badly formatted data'})


@app.route('/api/v1/addpolicy/', methods=['POST'])
def addpolicy():
    try:
        data = request.json
        API_KEY = data['API_KEY']
        POLICY = int(data['POLICY'] if data['POLICY'] in ("0", "1") else "0")

        cursor.execute("INSERT INTO POLICY (POLICY,API_KEY) VALUES(?,?);", (POLICY, API_KEY))
        connection.commit()
        api_response = make_response({'API_KEY': API_KEY, 'POLICY': str(POLICY), 'STATUS': 'OK'})
        api_response.headers["api_version"] = '1.0'
        api_response.headers["Content-Type"] = 'application/json'
        api_response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
        api_response.headers['Content-Security-Policy'] = "default-src 'self'"
        api_response.headers['X-Content-Type-Options'] = 'nosniff'
        api_response.headers['X-Frame-Options'] = 'SAMEORIGIN'
        return api_response
    except ValueError:
        return make_response({'Error': 'Badly formatted data'})
    except KeyError:
        return make_response({'Error': 'Badly formatted data'})


# Audit User Sessions
@app.route('/api/v1/audit/<string:token_id>', methods=['POST'])
def log_game_use(token_id):
    try:
        token = str(token_id)
        request_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        cursor.execute("INSERT INTO AUDIT(API,DATETIME,IP) VALUES(?,?,?);", (token, request_time, request.remote_addr))
        connection.commit()
        api_response = make_response({'Status': 'OK'})
        api_response.headers["api_version"] = '1.0'
        api_response.headers["Content-Type"] = 'application/json'
        api_response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
        api_response.headers['Content-Security-Policy'] = "default-src 'self'"
        api_response.headers['X-Content-Type-Options'] = 'nosniff'
        api_response.headers['X-Frame-Options'] = 'SAMEORIGIN'
        return api_response
    except ValueError:
        return make_response({'Error': 'Badly formatted data'})
    except KeyError:
        return make_response({'Error': 'Badly formatted data'})


# Get Number of Sessions so Session control can be Setup
@app.route('/api/v1/getsessions/<string:token_id>', methods=['POST'])
def get_sessions(token_id):
    try:
        token = token_id
        request_time = datetime.datetime.now().strftime("%Y-%m-%d")
        result = cursor.execute("select count(*) from AUDIT where API=? AND DATETIME LIKE ?", (token, '%' + request_time + '%')).fetchall()
        api_response=make_response({'Sessions': str(result[0][0]),'Status':'OK'})
        api_response.headers["api_version"] = '1.0'
        api_response.headers["Content-Type"] = 'application/json'
        api_response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
        api_response.headers['Content-Security-Policy'] = "default-src 'self'"
        api_response.headers['X-Content-Type-Options'] = 'nosniff'
        api_response.headers['X-Frame-Options'] = 'SAMEORIGIN'
        return api_response

    except ValueError:
        return make_response({'Error': 'Badly formatted data'})
    except KeyError:
        return make_response({'Error': 'Badly formatted data'})


if sys.version_info > (2, 7):
    if __name__ == '__main__':
        app.run(port=5001, host='0.0.0.0', debug=True, use_reloader=False, threaded=True)
else:
    print("Outdated Python Version")
