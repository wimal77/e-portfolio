import sys
import random
import uuid
import logging
from datetime import timedelta

from typing import Union, Any, NoReturn, Optional
from flask import Flask, render_template, request, g, session
from flask_babel import Babel


# Generate a Unique Session ID
def get_session_id() -> str:
    return uuid.uuid4().hex


session_id = get_session_id()
app = Flask(__name__)
app.secret_key = "37295735793759375983"
babel = Babel(app)

# Setup File Logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
file_handler = logging.FileHandler('Game.log')
log_formatter = logging.Formatter('%(asctime)s : %(levelname)s : %(name)s : %(message)s')
file_handler.setFormatter(log_formatter)
logger.addHandler(file_handler)

# Generate Board 3 * 3 grid
Board: list[str] = ['😀'] * 9
LANGUAGES: list[str] = ['en', 'de', 'es']


# Get the Locale of the client
@babel.localeselector
def get_locale() -> Optional[str]:
    return request.accept_languages.best_match(LANGUAGES)


def check_for_win(symbol: str, play_state: list) -> bool:
    Game: list = play_state
    Winner: bool = False
    # Horizontal Win
    if Game[0] == symbol and Game[1] == symbol and Game[2] == symbol:
        Winner = True
    if Game[3] == symbol and Game[4] == symbol and Game[5] == symbol:
        Winner = True
    if Game[6] == symbol and Game[7] == symbol and Game[8] == symbol:
        Winner = True

    # Vertical Win
    if Game[0] == symbol and Game[3] == symbol and Game[6] == symbol:
        Winner = True
    if Game[1] == symbol and Game[4] == symbol and Game[7] == symbol:
        Winner = True
    if Game[2] == symbol and Game[5] == symbol and Game[8] == symbol:
        Winner = True

    # Diagonal Win
    if Game[0] == symbol and Game[4] == symbol and Game[8] == symbol:
        Winner = True
    if Game[2] == symbol and Game[4] == symbol and Game[6] == symbol:
        Winner = True

    return Winner


# try and block a win from the player
def cpu_block_win(moves: list[str]) -> int:
    # First Row Horizontal Blocker
    if moves[0] == 'X' and moves[1] == 'X' and moves[2] not in ['X', 'O']:
        return 2
    if moves[1] == 'X' and moves[2] == 'X' and moves[0] not in ['X', 'O']:
        return 0
    if moves[0] == 'X' and moves[2] == 'X' and moves[1] not in ['X', 'O']:
        return 1

    # Second Row Horizontal Blocker
    if moves[3] == 'X' and moves[4] == 'X' and moves[5] not in ['X', 'O']:
        return 5
    if moves[4] == 'X' and moves[5] == 'X' and moves[3] not in ['X', 'O']:
        return 3
    if moves[3] == 'X' and moves[5] == 'X' and moves[4] not in ['X', 'O']:
        return 4

    # Third Row Horizontal Blocker
    if moves[6] == 'X' and moves[7] == 'X' and moves[8] not in ['X', 'O']:
        return 8
    if moves[7] == 'X' and moves[8] == 'X' and moves[6] not in ['X', 'O']:
        return 6
    if moves[6] == 'X' and moves[8] == 'X' and moves[7] not in ['X', 'O']:
        return 7

    # First Row Vertical Blocker
    if moves[0] == 'X' and moves[3] == 'X' and moves[6] not in ['X', 'O']:
        return 6
    if moves[3] == 'X' and moves[6] == 'X' and moves[0] not in ['X', 'O']:
        return 0
    if moves[0] == 'X' and moves[6] == 'X' and moves[3] not in ['X', 'O']:
        return 3

    # Second Row Vertical Blocker
    if moves[1] == 'X' and moves[4] == 'X' and moves[7] not in ['X', 'O']:
        return 7
    if moves[4] == 'X' and moves[7] == 'X' and moves[1] not in ['X', 'O']:
        return 1
    if moves[1] == 'X' and moves[7] == 'X' and moves[4] not in ['X', 'O']:
        return 4

    # Third Row Vertical Blocker
    if moves[2] == 'X' and moves[5] == 'X' and moves[8] not in ['X', 'O']:
        return 8
    if moves[5] == 'X' and moves[8] == 'X' and moves[2] not in ['X', 'O']:
        return 2
    if moves[2] == 'X' and moves[8] == 'X' and moves[5] not in ['X', 'O']:
        return 5

    # 1st Diagonal Blocker
    if moves[2] == 'X' and moves[4] == 'X' and moves[6] not in ['X', 'O']:
        return 6
    if moves[4] == 'X' and moves[6] == 'X' and moves[2] not in ['X', 'O']:
        return 2
    if moves[2] == 'X' and moves[6] == 'X' and moves[4] not in ['X', 'O']:
        return 4

    # 2nd Diagonal Blocker
    if moves[0] == 'X' and moves[4] == 'X' and moves[8] not in ['X', 'O']:
        return 8
    if moves[4] == 'X' and moves[8] == 'X' and moves[0] not in ['X', 'O']:
        return 0
    if moves[0] == 'X' and moves[8] == 'X' and moves[4] not in ['X', 'O']:
        return 4

    return 0xA


# Win The Game
def cpu_win(moves: list[str]):
    pass


# CPU to Make a Move
def Make_CPU_Move() -> NoReturn:
    Possible_Move: list[int] = []
    for x, y in enumerate(Board, start=0):
        if y not in ['X', 'O']:
            Possible_Move.append(x)
    if len(Possible_Move) > 0:
        if cpu_block_win(Board) < 10:
            Board[cpu_block_win(Board)] = "O"
        else:
            Board[random.choice(Possible_Move)] = "O"


@app.before_request
def before_request() -> Optional[any]:
    g.locale = str(get_locale())


@app.route('/', methods=['GET', 'POST'])
def game():  # put application's code here

    # Set Session_ID
    if 'session_id' not in session:
        session['session_id'] = session_id
        logger.info("New Game Session Started " + str(session['session_id']))

    if request.method == 'POST':
        # reset the board when the reset button is pressed
        if 'reset' in request.form:
            Board.clear()
            Board.extend('😀' * 9)

        if "choice" in request.form:
            index: int = int(request.form.get('choice'))
            if Board[index] not in ['X', 'O']:
                Board[index] = 'X'
                if not check_for_win('X', Board) and not check_for_win('O', Board):
                    # CPU Move Based on Rules
                    Make_CPU_Move()
            return render_template('index.htm', title='TicTacToe', Board=Board, choice=index, winner=check_for_win('X', Board), looser=check_for_win('O', Board), session_id=session['session_id'])
        else:
            return render_template('index.htm', title='TicTacToe', Board=Board, winner=False)
    else:
        return render_template('index.htm', title='TicTacToe', Board=Board, winner=False, session_id=session['session_id'])


# Ensure we are running python 3
if sys.version_info > (2, 7):
    if __name__ == '__main__':
        app.run(port=5001, host='0.0.0.0', debug=True, use_reloader=False, threaded=True)
else:
    print("Version of Python too Low")
