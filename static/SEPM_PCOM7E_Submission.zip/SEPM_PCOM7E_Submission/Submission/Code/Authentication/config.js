// Import the functions you need from the SDKs you need
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.7.0/firebase-app.js";
import { getAuth, onAuthStateChanged, signOut } from 'https://www.gstatic.com/firebasejs/9.7.0/firebase-auth.js'

const firebaseConfig = {
    apiKey: "AIzaSyCOZkVa_wub7QvphX2skZhMeyebX60NV1U",
    authDomain: "software-dev-cf89c.firebaseapp.com",
    databaseURL: "https://software-dev-cf89c-default-rtdb.firebaseio.com",
    projectId: "software-dev-cf89c",
    storageBucket: "software-dev-cf89c.appspot.com",
    messagingSenderId: "70838558259",
    appId: "1:70838558259:web:bfbcca6403f56e4f754d46",
    measurementId: "G-FHBP98WMJP"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export const auth = getAuth();
