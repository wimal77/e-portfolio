#code from https://www.geeksforgeeks.org/python-program-for-tower-of-hanoi/
# Recursive Python function to solve the tower of hanoi

# modifiyed to accept an input and print the number of move
 
def TowerOfHanoi(n , source, destination, auxiliary):
    global moves
    moves += 1
    
    if n==1:
        print ("Move disk 1 from source",source,"to destination",destination)
        return
    
    
    
    TowerOfHanoi(n-1, source, auxiliary, destination)
    print ("Move disk",n,"from source",source,"to destination",destination)
    TowerOfHanoi(n-1, auxiliary, destination, source)
         
# ask for number of disks
while True:
    try:
        n = int(input('please enter the number of disks:\n'))
        break

    except:
        continue

source = [i + 1 for i in reversed(range(n))]
destination = []
auxiliary = []

print(source, destination, auxiliary)
moves = 0

TowerOfHanoi(n,'A','B','C')
print("Number of moves: ", moves)

